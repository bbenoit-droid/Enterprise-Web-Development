# MoMo Transactions REST API

A secure REST API over MoMo SMS transaction data, built with Python's
standard-library `http.server` (no frameworks), protected with HTTP Basic
Auth, and backed by a simple XML → JSON parsing pipeline plus a
Linear Search vs. Dictionary Lookup comparison.

This builds on the MoMo Flow data model already confirmed for the team
(`users`, `categories`, `transactions`, `transaction_participants`,
`system_logs` — see `docs/erd_diagram.png` in the database repo).

## Project Structure

```
momo-flow/
├── api/
│   └── momo_api.py          # REST API (http.server), Basic Auth, CRUD
├── dsa/
│   ├── xml_parser.py        # Parses modified_sms_v2.xml -> list of dicts
│   └── search_compare.py    # Linear search vs dict lookup, timed comparison
├── data/
│   └── modified_sms_v2.xml  # Sample dataset (swap in the real file)
├── database/
│   └── database_setup.sql   # MySQL/MariaDB schema, seeds, constraint tests
├── docs/
│   ├── api_docs.md          # Endpoint docs, request/response examples, errors
│   └── Objective.md         # Assignment brief
├── examples/
│   └── json_schemas.json    # Example JSON payloads per table
├── tests/
│   ├── test_momo_api.py     # End-to-end API tests
│   └── test_parse_xml.py    # XML parser / index tests
├── screenshots/             # Put your curl/Postman test screenshots here
├── etl/                     # ETL modules — placeholders, not implemented yet
├── web/                     # Frontend files — placeholders, not implemented yet
├── scripts/                 # Shell helpers — placeholders, not implemented yet
└── README.md
```

## Requirements

- Python 3.8+
- No external packages required (standard library only)

## Setup

1. Clone the repo and `cd` into `momo-flow/`.
2. If you have the real `modified_sms_v2.xml`, drop it into `data/`,
   replacing the sample file (same attribute names, so no code changes
   needed — see `dsa/xml_parser.py`'s `FIELDS` list if your file uses
   different attribute names). Rows whose `id` is missing or not a number
   are skipped with a warning instead of crashing the API.

## Running the DSA comparison

```bash
cd dsa
python3 xml_parser.py       # parses the XML, prints a sample record, writes data/transactions.json
python3 search_compare.py   # times linear search vs dict lookup over the dataset
```

## Running the tests

```bash
python3 -m unittest discover -s tests -v
```

Covers the CRUD endpoints, authentication, error responses and the XML
parser (41 tests, standard library only — no test framework to install).

## Running the API

```bash
cd api
python3 momo_api.py
```

If port 8000 is already in use:

```bash
MOMO_API_PORT=8010 python3 momo_api.py
```

You should see:
```
MoMo API running on http://localhost:8000
Loaded 22 transactions from .../data/modified_sms_v2.xml
Basic Auth -> username: admin  password: momo_secret123
```

## Testing with curl

```bash
# API index — this is what http://localhost:8000/ returns after you log in
curl -u admin:momo_secret123 http://localhost:8000/

# No credentials -> 401 Unauthorized
curl -i http://localhost:8000/transactions

# List all transactions
curl -u admin:momo_secret123 http://localhost:8000/transactions

# Get one transaction
curl -u admin:momo_secret123 http://localhost:8000/transactions/1

# Create a transaction
curl -u admin:momo_secret123 -X POST -H "Content-Type: application/json" \
  -d '{"momo_ref_id":"38286099999","type":"TRANSFER","amount":1500,"sender":"Eric Manzi","receiver":"Keza Gasana","timestamp":"2026-06-01 09:00:00"}' \
  http://localhost:8000/transactions

# Update a transaction
curl -u admin:momo_secret123 -X PUT -H "Content-Type: application/json" \
  -d '{"amount":1800}' http://localhost:8000/transactions/23

# Delete a transaction
curl -u admin:momo_secret123 -X DELETE http://localhost:8000/transactions/23
```

Full docs (every endpoint, request/response bodies, and error codes) are in
[`docs/api_docs.md`](docs/api_docs.md).

## Screenshots to capture for submission

Save these into `screenshots/` per the assignment rubric:
1. Successful `GET /transactions` with valid auth
2. `GET /transactions` with wrong/missing credentials → 401
3. Successful `POST /transactions`
4. Successful `PUT /transactions/{id}`
5. Successful `DELETE /transactions/{id}`

## Notes on credentials

The username/password are hardcoded constants at the top of
`api/momo_api.py` for simplicity — see `docs/api_docs.md` for a
discussion of why Basic Auth is weak in production and what to use
instead (JWT, OAuth2).
