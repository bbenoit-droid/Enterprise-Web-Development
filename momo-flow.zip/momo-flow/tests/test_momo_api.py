"""End-to-end tests for api/momo_api.py.

Starts the real request handler on an ephemeral port inside the test process,
so no running server and no third-party packages are needed:

    python3 -m unittest discover -s tests -v
"""

import base64
import json
import os
import socket
import sys
import threading
import unittest
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "api"))

import momo_api  # noqa: E402

VALID_AUTH = "Basic " + base64.b64encode(b"admin:momo_secret123").decode()
INVALID_AUTH = "Basic " + base64.b64encode(b"admin:wrong-password").decode()

VALID_TRANSACTION = {
    "momo_ref_id": "38286099999",
    "type": "TRANSFER",
    "amount": 1500,
    "sender": "Eric Manzi",
    "receiver": "Keza Gasana",
    "timestamp": "2026-06-01 09:00:00",
}


class QuietHandler(momo_api.MomoRequestHandler):
    """The production handler without console logging."""

    def log_message(self, fmt, *args):
        pass


class ApiTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        momo_api.load_data()
        cls.server = momo_api.ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        # Reset the in-memory store so mutations never leak between tests.
        momo_api.load_data()

    # ---- helpers -------------------------------------------------------
    def request(self, method, path, body=None, auth=VALID_AUTH):
        data = None
        if body is not None:
            data = body if isinstance(body, bytes) else json.dumps(body).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=data, method=method
        )
        if auth:
            req.add_header("Authorization", auth)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                payload = response.read().decode()
                return response.status, json.loads(payload) if payload else None
        except urllib.error.HTTPError as error:
            payload = error.read().decode()
            error.close()
            return error.code, json.loads(payload) if payload else None

    def raw_request(self, payload):
        """Send a hand-built request; needed for invalid headers and to
        detect handler crashes (a crash returns no bytes at all)."""
        sock = socket.create_connection(("127.0.0.1", self.port), timeout=5)
        try:
            sock.sendall(payload)
            chunks = []
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                chunks.append(chunk)
            return b"".join(chunks)
        finally:
            sock.close()

    def raw_post(self, headers):
        request = (
            f"POST /transactions HTTP/1.1\r\n"
            f"Host: 127.0.0.1\r\n"
            f"Authorization: {VALID_AUTH}\r\n"
            f"{headers}"
            f"\r\n"
        )
        return self.raw_request(request.encode())


class AuthTests(ApiTestCase):
    def test_missing_credentials_returns_401(self):
        status, body = self.request("GET", "/transactions", auth=None)
        self.assertEqual(status, 401)
        self.assertIn("Unauthorized", body["error"])

    def test_wrong_password_returns_401(self):
        status, body = self.request("GET", "/transactions", auth=INVALID_AUTH)
        self.assertEqual(status, 401)

    def test_malformed_authorization_header_returns_401(self):
        status, _ = self.request("GET", "/transactions", auth="Basic ~~~not-base64~~~")
        self.assertEqual(status, 401)

    def test_valid_credentials_accepted(self):
        status, _ = self.request("GET", "/transactions")
        self.assertEqual(status, 200)


class ReadTests(ApiTestCase):
    def test_list_returns_every_transaction(self):
        status, body = self.request("GET", "/transactions")
        self.assertEqual(status, 200)
        self.assertEqual(body["count"], 22)
        self.assertEqual(len(body["transactions"]), 22)

    def test_get_one_returns_full_record(self):
        status, body = self.request("GET", "/transactions/1")
        self.assertEqual(status, 200)
        self.assertEqual(body["id"], 1)
        self.assertEqual(body["momo_ref_id"], "38286062599")
        self.assertIn("new_balance", body)

    def test_get_unknown_id_returns_404(self):
        status, body = self.request("GET", "/transactions/999")
        self.assertEqual(status, 404)
        self.assertIn("999", body["error"])

    def test_get_non_integer_id_returns_400(self):
        status, body = self.request("GET", "/transactions/abc")
        self.assertEqual(status, 400)
        self.assertIn("Invalid id", body["error"])

    def test_unknown_path_returns_404(self):
        status, body = self.request("GET", "/nope")
        self.assertEqual(status, 404)

    def test_root_requires_auth(self):
        status, _ = self.request("GET", "/", auth=None)
        self.assertEqual(status, 401)

    def test_root_returns_endpoint_index_instead_of_404(self):
        # Regression: a browser opened to http://localhost:8000 got prompted
        # for credentials and then landed on a dead-end 404.
        status, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("GET /transactions", body["endpoints"])
        self.assertIn("/transactions", body["hint"])

    def test_bare_url_is_treated_as_root(self):
        status, _ = self.request("GET", "")
        self.assertEqual(status, 200)

    def test_favicon_is_not_treated_as_root(self):
        status, _ = self.request("GET", "/favicon.ico")
        self.assertEqual(status, 404)


class CreateTests(ApiTestCase):
    def test_create_returns_201_and_assigns_next_id(self):
        status, body = self.request("POST", "/transactions", VALID_TRANSACTION)
        self.assertEqual(status, 201)
        self.assertEqual(body["id"], 23)
        self.assertEqual(body["momo_ref_id"], "38286099999")

        status, fetched = self.request("GET", "/transactions/23")
        self.assertEqual(status, 200)
        self.assertEqual(fetched["amount"], 1500)

    def test_create_missing_fields_returns_400(self):
        status, body = self.request("POST", "/transactions", {"amount": 1})
        self.assertEqual(status, 400)
        self.assertIn("Missing required fields", body["error"])

    def test_create_without_body_returns_400(self):
        status, body = self.request("POST", "/transactions")
        self.assertEqual(status, 400)
        self.assertIn("Missing required fields", body["error"])

    def test_create_malformed_json_returns_400(self):
        status, body = self.request("POST", "/transactions", b"{bad json")
        self.assertEqual(status, 400)
        self.assertEqual(body["error"], "Malformed JSON body")

    def test_create_array_body_returns_400(self):
        # Regression: a non-object body used to crash the handler (no response).
        status, body = self.request("POST", "/transactions", b"[1,2]")
        self.assertEqual(status, 400)
        self.assertIn("object", body["error"])

    def test_create_null_body_returns_400(self):
        status, body = self.request("POST", "/transactions", b"null")
        self.assertEqual(status, 400)
        self.assertIn("object", body["error"])

    def test_create_non_numeric_amount_returns_400(self):
        payload = dict(VALID_TRANSACTION, amount="lots")
        status, body = self.request("POST", "/transactions", payload)
        self.assertEqual(status, 400)
        self.assertIn("amount", body["error"])

    def test_create_boolean_amount_returns_400(self):
        payload = dict(VALID_TRANSACTION, amount=True)
        status, _ = self.request("POST", "/transactions", payload)
        self.assertEqual(status, 400)

    def test_create_duplicate_momo_ref_id_returns_409(self):
        payload = dict(VALID_TRANSACTION, momo_ref_id="38286062599")
        status, body = self.request("POST", "/transactions", payload)
        self.assertEqual(status, 409)
        self.assertIn("already exists", body["error"])

    def test_invalid_content_length_returns_400(self):
        # Regression: this used to raise ValueError inside the handler.
        response = self.raw_post("Content-Length: abc\r\n")
        self.assertTrue(response, "handler closed the connection without responding")
        self.assertIn(b"400", response.split(b"\r\n", 1)[0])
        self.assertIn(b"Invalid Content-Length", response)

    def test_negative_content_length_returns_400(self):
        # Regression: this used to block forever with no response.
        response = self.raw_post("Content-Length: -1\r\n")
        self.assertTrue(response, "handler closed the connection without responding")
        self.assertIn(b"400", response.split(b"\r\n", 1)[0])
        self.assertIn(b"negative", response)


class UpdateTests(ApiTestCase):
    def test_put_updates_fields_and_keeps_id(self):
        status, body = self.request("PUT", "/transactions/1", {"amount": 1800})
        self.assertEqual(status, 200)
        self.assertEqual(body["id"], 1)
        self.assertEqual(body["amount"], 1800)
        self.assertEqual(body["momo_ref_id"], "38286062599")

    def test_put_cannot_change_id(self):
        status, body = self.request("PUT", "/transactions/1", {"id": 999})
        self.assertEqual(status, 200)
        self.assertEqual(body["id"], 1)

    def test_put_array_body_returns_400(self):
        # Regression: list()/int() bodies used to crash the handler.
        for raw in (b"[1,2]", b"123", b'"just a string"'):
            with self.subTest(raw=raw):
                status, body = self.request("PUT", "/transactions/1", raw)
                self.assertEqual(status, 400)
                self.assertIn("object", body["error"])

    def test_put_null_body_reports_non_object_body(self):
        # Regression: valid JSON `null` was reported as "Malformed JSON body".
        status, body = self.request("PUT", "/transactions/1", b"null")
        self.assertEqual(status, 400)
        self.assertEqual(body["error"], "JSON body must be an object")

    def test_put_unknown_id_returns_404(self):
        status, _ = self.request("PUT", "/transactions/999", {"amount": 1})
        self.assertEqual(status, 404)

    def test_put_invalid_id_returns_400(self):
        status, _ = self.request("PUT", "/transactions/xyz", {"amount": 1})
        self.assertEqual(status, 400)

    def test_put_non_numeric_amount_returns_400(self):
        status, body = self.request("PUT", "/transactions/1", {"amount": "lots"})
        self.assertEqual(status, 400)
        self.assertIn("amount", body["error"])

    def test_put_duplicate_momo_ref_id_returns_409(self):
        status, _ = self.request("PUT", "/transactions/2", {"momo_ref_id": "38286062599"})
        self.assertEqual(status, 409)

    def test_put_keeping_own_momo_ref_id_is_allowed(self):
        status, _ = self.request("PUT", "/transactions/1", {"momo_ref_id": "38286062599"})
        self.assertEqual(status, 200)


class DeleteTests(ApiTestCase):
    def test_delete_removes_the_transaction(self):
        status, body = self.request("DELETE", "/transactions/1")
        self.assertEqual(status, 200)
        self.assertEqual(body["deleted"]["id"], 1)

        status, _ = self.request("GET", "/transactions/1")
        self.assertEqual(status, 404)

        status, listing = self.request("GET", "/transactions")
        self.assertEqual(listing["count"], 21)

    def test_delete_unknown_id_returns_404(self):
        status, _ = self.request("DELETE", "/transactions/999")
        self.assertEqual(status, 404)


class ConcurrencyTests(ApiTestCase):
    def test_parallel_creates_get_unique_ids(self):
        payloads = [dict(VALID_TRANSACTION, momo_ref_id=f"CONC-{i:03d}") for i in range(20)]
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(
                pool.map(lambda p: self.request("POST", "/transactions", p), payloads)
            )
        created = [body["id"] for status, body in results if status == 201]
        self.assertEqual(len(created), 20, [r[0] for r in results])
        self.assertEqual(len(set(created)), 20, "ids must stay unique under load")


if __name__ == "__main__":
    unittest.main()
