"""Tests for dsa/xml_parser.py (parse + index building)."""

import os
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "dsa"))

from xml_parser import FIELDS, build_index, parse_sms_xml  # noqa: E402

SAMPLE_XML = os.path.join(HERE, "..", "data", "modified_sms_v2.xml")


def write_xml(body):
    handle = tempfile.NamedTemporaryFile("w", suffix=".xml", delete=False)
    handle.write(body)
    handle.close()
    return handle.name


class ParseSampleDatasetTest(unittest.TestCase):
    def test_parses_all_records(self):
        records = parse_sms_xml(SAMPLE_XML)
        self.assertEqual(len(records), 22)
        self.assertTrue(all(isinstance(r["id"], int) for r in records))

    def test_numeric_fields_are_cast(self):
        record = parse_sms_xml(SAMPLE_XML)[0]
        self.assertIsInstance(record["amount"], float)
        self.assertIsInstance(record["fee"], float)
        self.assertIsInstance(record["raw_sms_date"], int)
        self.assertIsInstance(record["timestamp"], str)

    def test_all_expected_fields_present(self):
        record = parse_sms_xml(SAMPLE_XML)[0]
        for field in FIELDS:
            self.assertIn(field, record)

    def test_missing_attributes_default_to_none(self):
        path = write_xml('<smses count="1"><sms id="1" amount="10.00"/></smses>')
        try:
            record = parse_sms_xml(path)[0]
        finally:
            os.unlink(path)
        self.assertEqual(record["id"], 1)
        self.assertEqual(record["amount"], 10.0)
        self.assertIsNone(record["sender"])
        self.assertIsNone(record["status"])

    def test_non_numeric_amount_is_left_as_string(self):
        path = write_xml('<smses count="1"><sms id="1" amount="lots"/></smses>')
        try:
            record = parse_sms_xml(path)[0]
        finally:
            os.unlink(path)
        self.assertEqual(record["amount"], "lots")

    def test_malformed_xml_raises_parse_error(self):
        path = write_xml("<smses><sms>")
        try:
            with self.assertRaises(ET.ParseError):
                parse_sms_xml(path)
        finally:
            os.unlink(path)


class BuildIndexTest(unittest.TestCase):
    def test_indexes_by_id(self):
        records = parse_sms_xml(SAMPLE_XML)
        index = build_index(records)
        self.assertEqual(len(index), 22)
        self.assertEqual(index[1]["momo_ref_id"], "38286062599")

    def test_skips_records_without_an_integer_id(self):
        # A real-world export with a stray row must not produce a None key,
        # which would crash the API at startup (max() over int and None).
        path = write_xml(
            '<smses count="2">'
            '<sms momo_ref_id="AAA" amount="10.00"/>'
            '<sms id="7" momo_ref_id="BBB" amount="20.00"/>'
            '<sms id="oops" momo_ref_id="CCC" amount="30.00"/>'
            "</smses>"
        )
        try:
            records = parse_sms_xml(path)
        finally:
            os.unlink(path)
        index = build_index(records)
        self.assertEqual(list(index), [7])
        self.assertIsInstance(max(index), int)

    def test_empty_input_gives_empty_index(self):
        self.assertEqual(build_index([]), {})


if __name__ == "__main__":
    unittest.main()
